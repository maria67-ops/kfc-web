// Menú de KFC
const numeroWhatsApp = "879789"; // KFC: pedidos por WhatsApp (España +34)

const productos = [
  { id: 1, nombre: "Durum KFC", categoria: "kebab", precio: 6.50, descripcion: "Carne, lechuga, tomate y salsa de la casa.", imagen: "https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&w=800&q=80", etiqueta: "Favorito" },
  { id: 2, nombre: "Kebab clásico", categoria: "kebab", precio: 5.50, descripcion: "Kebab de siempre con pan crujiente.", imagen: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80" },
  { id: 3, nombre: "Burger KFC", categoria: "burger", precio: 4.99, descripcion: "Hamburguesa con queso, lechuga y salsa.", imagen: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80", etiqueta: "¡Precio top!" },
  { id: 4, nombre: "Tacos crujientes", categoria: "tacos", precio: 7.50, descripcion: "Tacos para darte un capricho.", imagen: "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?auto=format&fit=crop&w=800&q=80" },
  { id: 5, nombre: "Pizza especial", categoria: "pizza", precio: 9.00, descripcion: "Pizza al horno con queso e ingredientes variados.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80" },
  { id: 6, nombre: "Plato combinado", categoria: "platos", precio: 8.90, descripcion: "Carne, patatas y ensalada.", imagen: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80" },
  { id: 7, nombre: "Ensalada de queso de cabra", categoria: "ensaladas", precio: 2.99, descripcion: "Ensalada fresca con queso de cabra.", imagen: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80", etiqueta: "Desde 2,99 €" },
  { id: 8, nombre: "Ensalada de atún", categoria: "ensaladas", precio: 3.99, descripcion: "Ensalada fresca con atún.", imagen: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80" },
  { id: 9, nombre: "Ensalada Chicken", categoria: "ensaladas", precio: 4.99, descripcion: "Ensalada con pollo.", imagen: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80" },
  { id: 10, nombre: "Ensalada tropical", categoria: "ensaladas", precio: 4.99, descripcion: "Una ensalada fresca de inspiración tropical.", imagen: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80" },
  { id: 11, nombre: "Chicken Crispy · 6 piezas + 2 bebidas", categoria: "pollo", precio: 12.99, descripcion: "6 piezas de Chicken Crispy con 2 bebidas incluidas.", imagen: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=800&q=80", etiqueta: "Combo" },
  { id: 12, nombre: "Chicken · 8 piezas", categoria: "pollo", precio: 13.99, descripcion: "8 piezas de pollo.", imagen: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=800&q=80" },
  { id: 13, nombre: "2 piezas de pollo + patatas", categoria: "pollo", precio: 3.50, descripcion: "Dos piezas de pollo acompañadas de patatas.", imagen: "https://images.unsplash.com/photo-1562967914-608f82629710?auto=format&fit=crop&w=800&q=80", etiqueta: "Oferta" },
  { id: 14, nombre: "Hamburguesa Chicken sola", categoria: "burger", precio: 2.50, descripcion: "Hamburguesa de pollo.", imagen: "https://images.unsplash.com/photo-1606755962773-d324e0a13086?auto=format&fit=crop&w=800&q=80" },
  { id: 15, nombre: "Menú Hamburguesa Chicken", categoria: "burger", precio: 4.99, descripcion: "Hamburguesa de pollo en menú.", imagen: "https://images.unsplash.com/photo-1606755962773-d324e0a13086?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú" },
  { id: 16, nombre: "Hamburguesa Ternera sola", categoria: "burger", precio: 2.50, descripcion: "Hamburguesa de ternera.", imagen: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80" },
  { id: 17, nombre: "Menú Hamburguesa Ternera", categoria: "burger", precio: 4.99, descripcion: "Hamburguesa de ternera en menú.", imagen: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú" },
  { id: 18, nombre: "Hamburguesa Doble Beef sola", categoria: "burger", precio: 3.90, descripcion: "Hamburguesa doble de ternera.", imagen: "https://images.unsplash.com/photo-1553979459-d2229ba7433a?auto=format&fit=crop&w=800&q=80" },
  { id: 19, nombre: "Menú Hamburguesa Doble Beef", categoria: "burger", precio: 6.90, descripcion: "Hamburguesa doble de ternera en menú.", imagen: "https://images.unsplash.com/photo-1553979459-d2229ba7433a?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú" },
  { id: 20, nombre: "Hamburguesa Zinger sola", categoria: "burger", precio: 3.90, descripcion: "Hamburguesa de pollo rebozado y crujiente.", imagen: "https://images.unsplash.com/photo-1606755962773-d324e0a13086?auto=format&fit=crop&w=800&q=80" },
  { id: 21, nombre: "Menú Hamburguesa Zinger", categoria: "burger", precio: 6.90, descripcion: "Hamburguesa Zinger en menú.", imagen: "https://images.unsplash.com/photo-1606755962773-d324e0a13086?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú" },
  { id: 22, nombre: "Pizza kebab mixta · sola", categoria: "pizza", precio: 9.90, descripcion: "Pizza con kebab mixto.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80" },
  { id: 23, nombre: "Pizza kebab ternera · sola", categoria: "pizza", precio: 9.90, descripcion: "Pizza con kebab de ternera.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80" },
  { id: 24, nombre: "Pizza kebab pollo · sola", categoria: "pizza", precio: 9.90, descripcion: "Pizza con kebab de pollo.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80" },
  { id: 25, nombre: "Pizza atún y pollo · sola", categoria: "pizza", precio: 9.90, descripcion: "Pizza con atún y pollo.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80" },
  { id: 26, nombre: "Pizza 4 quesos · sola", categoria: "pizza", precio: 9.90, descripcion: "Pizza de cuatro quesos.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80" },
  { id: 27, nombre: "Pizza margarita · sola", categoria: "pizza", precio: 9.90, descripcion: "Pizza margarita clásica.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80" },
  { id: 28, nombre: "Pizza atún y queso · sola", categoria: "pizza", precio: 9.90, descripcion: "Pizza con atún y queso.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80" },
  { id: 29, nombre: "Menú pizza kebab mixta", categoria: "pizza", precio: 12.99, descripcion: "Pizza kebab mixta en menú.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú 12,99 €" },
  { id: 30, nombre: "Menú pizza kebab ternera", categoria: "pizza", precio: 12.99, descripcion: "Pizza kebab de ternera en menú.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú 12,99 €" },
  { id: 31, nombre: "Menú pizza kebab pollo", categoria: "pizza", precio: 12.99, descripcion: "Pizza kebab de pollo en menú.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú 12,99 €" },
  { id: 32, nombre: "Menú pizza atún y pollo", categoria: "pizza", precio: 12.99, descripcion: "Pizza de atún y pollo en menú.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú 12,99 €" },
  { id: 33, nombre: "Menú pizza 4 quesos", categoria: "pizza", precio: 12.99, descripcion: "Pizza cuatro quesos en menú.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú 12,99 €" },
  { id: 34, nombre: "Menú pizza margarita", categoria: "pizza", precio: 12.99, descripcion: "Pizza margarita en menú.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú 12,99 €" },
  { id: 35, nombre: "Menú pizza atún y queso", categoria: "pizza", precio: 12.99, descripcion: "Pizza de atún y queso en menú.", imagen: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80", etiqueta: "Menú 12,99 €" },
  { id: 36, nombre: "Menú infantil nuggets", categoria: "infantil", precio: 4.90, descripcion: "Nuggets, patatas y zumo.", imagen: "https://images.unsplash.com/photo-1562967914-608f82629710?auto=format&fit=crop&w=800&q=80", etiqueta: "Infantil" },
  { id: 37, nombre: "6 nuggets solos", categoria: "pollo", precio: 3.90, descripcion: "Ración de 6 nuggets, sin acompañamiento.", imagen: "https://images.unsplash.com/photo-1562967914-608f82629710?auto=format&fit=crop&w=800&q=80" },
  { id: 38, nombre: "Plato kebab infantil", categoria: "infantil", precio: 3.90, descripcion: "Carne de kebab y patatas. Añade bebida por 1 € más.", imagen: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80", etiqueta: "Con bebida: 4,90 €" },
  { id: 39, nombre: "Plato kebab infantil + bebida", categoria: "infantil", precio: 4.90, descripcion: "Carne de kebab, patatas y bebida.", imagen: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80" }
];

const entradasBlog = [
  {
    titulo: "¿Qué pedir si es tu primera vez en KFC?",
    fecha: "12 de septiembre de 2026",
    texto: "Si todavía no sabes qué elegir, puedes empezar con un kebab clásico o probar nuestro Durum KFC. Son opciones sencillas para conocer la carta.",
    enlace: "blog-primera-vez.html"
  },
  {
    titulo: "Una cena rápida para compartir",
    fecha: "18 de septiembre de 2026",
    texto: "Una pizza y unas raciones para compartir pueden ser una buena opción cuando quedas con amigos o no te apetece cocinar.",
    enlace: "blog-cena-para-compartir.html"
  },
  {
    titulo: "Nuestros favoritos de la carta",
    fecha: "25 de septiembre de 2026",
    texto: "Los kebabs, las hamburguesas y los tacos son algunas de las opciones que puedes encontrar en nuestra carta. Elige lo que más te apetezca.",
    enlace: "blog-favoritos.html"
  },
  {
    titulo: "¡Novedad en KFC: llega el taco francés!",
    fecha: "13 de octubre de 2026",
    texto: "Tenemos una novedad para quienes quieren probar algo diferente: el taco francés. Una nueva opción para descubrir en KFC y disfrutar de una comida con mucho sabor.",
    enlace: "blog-taco-frances.html"
  }
];

const carrito = {};
const formatoEuro = precio => precio.toLocaleString("es-ES", {
  style: "currency",
  currency: "EUR"
});

// Muestra los productos de la carta.
function mostrarProductos(categoria = "todos") {
  const contenedor = document.querySelector("#menuGrid");
  if (!contenedor) return;

  const lista = categoria === "todos"
    ? productos
    : productos.filter(producto => producto.categoria === categoria);

  contenedor.innerHTML = lista.map(producto => `
    <article class="food-card">
      <div class="food-image-wrap">
        <img class="food-image" src="${producto.imagen}" alt="${producto.nombre}" loading="lazy">
        ${producto.etiqueta ? `<span class="food-label">${producto.etiqueta}</span>` : ""}
      </div>
      <div class="food-details">
        <div class="food-title-row">
          <h3>${producto.nombre}</h3>
          <span class="food-price">${formatoEuro(producto.precio)}</span>
        </div>
        <p>${producto.descripcion}</p>
        <button class="add-button" data-add="${producto.id}">Añadir al pedido</button>
      </div>
    </article>
  `).join("");
}

// Añade tres secciones sencillas si todavía no están en el HTML.
function crearSecciones() {
  const principal = document.querySelector("main") || document.body;

  if (!document.querySelector("#sobreKFC")) {
    principal.insertAdjacentHTML("beforeend", `
      <section id="sobreKFC">
        <h2>Sobre KFC</h2>
        <p>En KFC encontrarás kebabs, hamburguesas, pizzas y otros platos para disfrutar a tu manera.</p>
      </section>
      <section id="consejos">
        <h2>Ideas para tu próxima comida</h2>
        <p>¿Tienes hambre y no sabes qué elegir? Echa un vistazo a la carta y prueba algo diferente la próxima vez.</p>
      </section>
    `);
  }

  if (!document.querySelector("#blogGrid")) {
    principal.insertAdjacentHTML("beforeend", `
      <section id="blog">
        <h2>Blog de KFC</h2>
        <div id="blogGrid"></div>
      </section>
    `);
  }

  const blog = document.querySelector("#blogGrid");
  if (blog) {
    blog.innerHTML = entradasBlog.map(entrada => `
      <article class="blog-card">
        <h3>${entrada.titulo}</h3>
        <small>${entrada.fecha}</small>
        <p>${entrada.texto}</p>
        <a class="blog-link" href="${entrada.enlace}">Leer entrada completa →</a>
      </article>
    `).join("");
  }
}

// Actualiza el número de artículos y el precio del carrito.
function actualizarCarrito() {
  let cantidad = 0;
  let total = 0;

  productos.forEach(producto => {
    const unidades = carrito[producto.id] || 0;
    cantidad += unidades;
    total += producto.precio * unidades;
  });

  const numero = document.querySelector("#cartCount");
  const precio = document.querySelector("#cartTotal");
  const barra = document.querySelector("#cartBar");

  if (numero) numero.textContent = cantidad;
  if (precio) precio.textContent = formatoEuro(total);
  if (barra) barra.classList.toggle("visible", cantidad > 0);
}

// Cambia la categoría de productos al pulsar un filtro.
document.querySelectorAll("[data-filter]").forEach(boton => {
  boton.addEventListener("click", () => {
    document.querySelectorAll("[data-filter]").forEach(item => item.classList.remove("active"));
    boton.classList.add("active");
    mostrarProductos(boton.dataset.filter);
  });
});

// Gestiona los botones para añadir productos.
const menu = document.querySelector("#menuGrid");
if (menu) {
  menu.addEventListener("click", evento => {
    const boton = evento.target.closest("[data-add]");
    if (!boton) return;

    const id = Number(boton.dataset.add);
    carrito[id] = (carrito[id] || 0) + 1;
    actualizarCarrito();
    boton.textContent = "¡Añadido!";
  });
}

// Envía el pedido por WhatsApp.
const botonPedido = document.querySelector("#checkoutButton");
if (botonPedido) {
  botonPedido.addEventListener("click", () => {
    if (!numeroWhatsApp) {
      alert("Añade tu número de WhatsApp al principio del archivo para activar los pedidos.");
      return;
    }

    const lineas = [];
    let total = 0;

    productos.forEach(producto => {
      const unidades = carrito[producto.id] || 0;
      if (unidades > 0) {
        lineas.push(`${unidades} x ${producto.nombre} - ${formatoEuro(unidades * producto.precio)}`);
        total += unidades * producto.precio;
      }
    });

    if (lineas.length === 0) {
      alert("Primero añade algún producto al pedido.");
      return;
    }

    const mensaje = `Hola KFC, quiero hacer este pedido:\n${lineas.join("\n")}\nTotal: ${formatoEuro(total)}`;
    window.open(`https://wa.me/${numeroWhatsApp}?text=${encodeURIComponent(mensaje)}`, "_blank");
  });
}

// Menú para móviles.
const botonMenu = document.querySelector("#menuToggle");
const navegacion = document.querySelector("#mainNav");

if (botonMenu && navegacion) {
  botonMenu.addEventListener("click", () => {
    navegacion.classList.toggle("open");
  });

  navegacion.querySelectorAll("a").forEach(enlace => {
    enlace.addEventListener("click", () => navegacion.classList.remove("open"));
  });
}

const anio = document.querySelector("#year");
if (anio) anio.textContent = new Date().getFullYear();

mostrarProductos();
crearSecciones();
